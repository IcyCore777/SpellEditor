// Supported with union (c) 2018 Union team

#ifndef __OMENU__TOOLS_H__VER3__
#define __OMENU__TOOLS_H__VER3__

namespace Gothic_II_Addon {

} // namespace Gothic_II_Addon

#endif // __OMENU__TOOLS_H__VER3__