// Supported with union (c) 2018 Union team

#ifndef __OINPUT_H__VER3__
#define __OINPUT_H__VER3__

namespace Gothic_II_Addon {

} // namespace Gothic_II_Addon

#endif // __OINPUT_H__VER3__