// Supported with union (c) 2018 Union team

#ifndef __ZOPTION__CONST_H__VER3__
#define __ZOPTION__CONST_H__VER3__

namespace Gothic_II_Addon {

} // namespace Gothic_II_Addon

#endif // __ZOPTION__CONST_H__VER3__