// Supported with union (c) 2018 Union team

#ifndef __ZAI_CAMERA__DIALOG_H__VER3__
#define __ZAI_CAMERA__DIALOG_H__VER3__

namespace Gothic_II_Addon {

} // namespace Gothic_II_Addon

#endif // __ZAI_CAMERA__DIALOG_H__VER3__